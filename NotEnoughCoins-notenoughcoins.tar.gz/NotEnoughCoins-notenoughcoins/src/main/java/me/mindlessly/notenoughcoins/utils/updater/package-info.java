package me.mindlessly.notenoughcoins.utils.updater;
/*
  Taken from Wynntils under GNU Affero General Public License v3.0
  Modified
  https://github.com/Wynntils/Wynntils/blob/development/LICENSE

  @author Wynntils
 * <p>
 * Taken from Skytils under GNU Affero General Public License v3.0
 * Modified
 * https://github.com/Skytils/SkytilsMod/blob/1.x/LICENSE.md
 * @author Skytils
 */
